Extract all files, then open report_trade_failures_fa.html in Chrome or Firefox. This report contains all 4108 diagnostic charts.
HTML SHA256: 5e4920f2811120e32b2ecab5143c5b31e402bf652035910842280b7849b1f3ee
